﻿using Moq;
using NUnit.Framework;
using transportdb.Controllers;
using transportdb.Models;
using transportdb.Services;
using Microsoft.Extensions.Options;
using MongoDB.Driver;
using MongoDB.Bson;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics.Metrics;

namespace Testing
{
    [TestFixture]
    public class TesterClass
    {
        CarriersController carriersContoroller;
        CustomersController customersController;
        InvoicesController invoicesController;
        OperatorsController operatorsController;
        OrdersController ordersController;
        RoutesController routesController;
        TemperaturesController temperaturesController;
        ToursController toursController;
        TrailersController trailersController;
        TrucksController trucksController;

        Mock<IMongoDbService> mockService = new Mock<IMongoDbService>(MockBehavior.Strict);

        [SetUp]
        public void Setup()
        {



            var carriers = new List<Carriers>();

            Carriers carrier1 = new Carriers { Id= "ObjectId('65291e40052c1b670cade50f')", carrier_id = 1, first_name = "Jane", last_name = "Doe", license_date = new DateTime(2026, 10, 10), truck_nrplate = "NHOL5K" };
            Carriers carrier2 = new Carriers { Id = "ObjectId('65291e40052c1b670cade510')", carrier_id = 2, first_name = "Sam", last_name = "Hudson", license_date = new DateTime(2024, 12, 02), truck_nrplate = "KL45KS" };

            carriers.Add(carrier1);
            carriers.Add(carrier2);

            var customers = new List<Customers>();

            Customers customer1 = new Customers { Id = "ObjectId('65291e4d052c1b670cade526')", customer_id = 1, customer_name = "Hunbrothers", contact = "Vaughan@fermentum.gov", city = "Budapest" };
            Customers customer2 = new Customers { Id = "ObjectId('65291e4d052c1b670cade527')", customer_id = 2, customer_name = "English muffins", contact = "Wang@eu.net", city = "London" };

            customers.Add(customer1);
            customers.Add(customer2);

            var invoices = new List<Invoices>();

            Invoices invoice1 = new Invoices { Id = "ObjectId('65291dad052c1b670ca89f13')", invoice_nr = 1, price = 1093, currency = "GBP" };
            Invoices invoice2 = new Invoices { Id = "ObjectId('65291dad052c1b670ca89f14')", invoice_nr = 2, price = 1965, currency = "EUR" };
            Invoices invoice3 = new Invoices { Id = "ObjectId('65291dad052c1b670ca89f15')", invoice_nr = 3, price = 3190, currency = "EUR" };
            Invoices invoice4 = new Invoices { Id = "ObjectId('65291dad052c1b670ca89f16')", invoice_nr = 4, price = 1451, currency = "EUR" };
            Invoices invoice5 = new Invoices { Id = "ObjectId('65291dad052c1b670ca89f17')", invoice_nr = 5, price = 4566, currency = "GBP" };

            invoices.Add(invoice1);
            invoices.Add(invoice2);
            invoices.Add(invoice3);
            invoices.Add(invoice4);
            invoices.Add(invoice5);

            var operators = new List<Operators>();

            Operators operator1 = new Operators { Id = "ObjectId('65169cffc7591a302ee973d8')", to_id = 1, first_name = "Flynn", last_name = "Cervantes", start_date = new DateTime(2019, 11, 20) };
            Operators operator2 = new Operators { Id = "ObjectId('65169cffc7591a302ee973d9')", to_id = 2, first_name = "Russel", last_name = "Black", start_date = new DateTime(2021, 12, 04) };

            operators.Add(operator1);
            operators.Add(operator2);

            var orders = new List<Orders>();

            Orders order1 = new Orders { Id = "ObjectId('65291c09052c1b670c9e131c')", order_nr = 9000, customer_id = 4, temperature_name = "dry", palet_number = 5 };
            Orders order2 = new Orders { Id = "ObjectId('65291c09052c1b670c9e131d')", order_nr = 9001, customer_id = 5, temperature_name = "cold", palet_number = 23 };
            Orders order3 = new Orders { Id = "ObjectId('65291c09052c1b670c9e131e')", order_nr = 9002, customer_id = 4, temperature_name = "cold", palet_number = 48 };
            Orders order4 = new Orders { Id = "ObjectId('65291c09052c1b670c9e131f')", order_nr = 9003, customer_id = 5, temperature_name = "frozen", palet_number = 3 };
            Orders order5 = new Orders { Id = "ObjectId('65291c09052c1b670c9e1320')", order_nr = 9004, customer_id = 10, temperature_name = "warm", palet_number = 21 };

            orders.Add(order1);
            orders.Add(order2);
            orders.Add(order3);
            orders.Add(order4);
            orders.Add(order5);

            var routes = new List<Routes>();

            Routes route1 = new Routes { Id = "ObjectId('65291e59052c1b670cade53c')", route_id = 1, start_loc = "Warsaw", destination = "Paris" };
            Routes route2 = new Routes { Id = "ObjectId('65291e59052c1b670cade53d')", route_id = 2, start_loc = "Kiyiv", destination = "Alsonemedi" };

            routes.Add(route1);
            routes.Add(route2);

            var temperatures = new List<Temperatures>();

            Temperatures temperature1 = new Temperatures { Id = "ObjectId('65292115052c1b670cade57e')", temperature_name = "cold", celsius = 23, signal = "-" };
            Temperatures temperature2 = new Temperatures { Id = "ObjectId('65292115052c1b670cade57f')", temperature_name = "dry" };

            temperatures.Add(temperature1);
            temperatures.Add(temperature2);

            var tours = new List<Tours>();

            Tours tour1 = new Tours { Id = "ObjectId('65291c78052c1b670ca335eb')", tour_nr = 2600000, TO_id = 5, carrier_id = 7, route_id = 38, invoice_nr = 1, order_nr = 9000, tour_end = new DateTime(2020, 09, 17) };
            Tours tour2 = new Tours { Id = "ObjectId('65291c78052c1b670ca335ec')", tour_nr = 2600001, TO_id = 4, carrier_id = 18, route_id = 35, invoice_nr = 2, order_nr = 9001, tour_end = new DateTime(2021, 01, 13) };
            Tours tour3 = new Tours { Id = "ObjectId('65291c78052c1b670ca335ed')", tour_nr = 2600002, TO_id = 9, carrier_id = 13, route_id = 4, invoice_nr = 3, order_nr = 9002, tour_end = new DateTime(2021, 05, 20) };
            Tours tour4 = new Tours { Id = "ObjectId('65291c78052c1b670ca335ee')", tour_nr = 2600003, TO_id = 6, carrier_id = 15, route_id = 49, invoice_nr = 4, order_nr = 9003, tour_end = new DateTime(2022, 02, 28) };
            Tours tour5 = new Tours { Id = "ObjectId('65291c78052c1b670ca335ef')",  tour_nr = 2600004, TO_id = 10, carrier_id = 10, route_id = 16, invoice_nr = 5, order_nr = 9004, tour_end = new DateTime(2021, 08, 08) };

            tours.Add(tour1);
            tours.Add(tour2);
            tours.Add(tour3);
            tours.Add(tour4);
            tours.Add(tour5);

            var trailers = new List<Trailers>();

            Trailers trailer1 = new Trailers { Id = "ObjectId('65292254052c1b670cade5bc')", trailer_nrplate="WUW6FM", type="flatbed", country="Spain"};
            Trailers trailer2 = new Trailers { Id = "ObjectId('65292254052c1b670cade5bd')", trailer_nrplate = "8N7DKZ", type = "stepdeck", country = "United Kingdom" };

            trailers.Add(trailer1);
            trailers.Add(trailer2);

            var trucks = new List<Trucks>();

            Trucks truck1 = new Trucks { Id = "ObjectId('65292137052c1b670cade5a2')", truck_nrplate = "B4HG53", trailer_nrplate = "WUW6FM", manufacturer = "Ford", type = "Mini", country = "Spain" };
            Trucks truck2 = new Trucks { Id = "ObjectId('65292137052c1b670cade5a3')", truck_nrplate = "ASP59K", trailer_nrplate = "8N7DKZ", manufacturer = "Volvo", type = "Max", country = "Romania" };

            trucks.Add(truck1);
            trucks.Add(truck2);

            mockService.Setup((x) => x.GetAllCarriers()).ReturnsAsync(carriers);
            mockService.Setup((x) => x.GetAllCustomers()).ReturnsAsync(customers);
            mockService.Setup((x) => x.GetAllInvoices()).ReturnsAsync(invoices);
            mockService.Setup((x) => x.GetAllOperators()).ReturnsAsync(operators);
            mockService.Setup((x) => x.GetAllOrders()).ReturnsAsync(orders);
            mockService.Setup((x) => x.GetAllRoutes()).ReturnsAsync(routes);
            mockService.Setup((x) => x.GetAllTemperatures()).ReturnsAsync(temperatures);
            mockService.Setup((x) => x.GetAllTours()).ReturnsAsync(tours);
            mockService.Setup((x) => x.GetAllTrailers()).ReturnsAsync(trailers);
            mockService.Setup((x) => x.GetAllTrucks()).ReturnsAsync(trucks);

            carriersContoroller = new CarriersController(mockService.Object);
            customersController = new CustomersController(mockService.Object);
            invoicesController = new InvoicesController(mockService.Object);
            operatorsController = new OperatorsController(mockService.Object);
            ordersController = new OrdersController(mockService.Object);
            routesController = new RoutesController(mockService.Object);
            temperaturesController = new TemperaturesController(mockService.Object);
            toursController = new ToursController(mockService.Object);
            trailersController=new TrailersController(mockService.Object);
            trucksController=new TrucksController(mockService.Object);

            
        }



        [Test]
        public void CreateCarrierWithExpiredLicense()
        {
            //nem lehet lejárt jogsival carriert regisztrálni
            Carriers carrier = new Carriers { Id = "ObjectId('67291e80052c1b670cade510')", carrier_id = 6, first_name = "Tom", last_name = "Lilith", license_date = new DateTime(2022, 12, 02), truck_nrplate = "KLS678" };
            Assert.That(() => carriersContoroller.Create(carrier), Throws.TypeOf<ArgumentException>());
        }

        [Test]
        public void CreateCustomerWhoIsBlacklisted()
        {
            //nem lehet feketelistás megrendelőt létrehozni
            Customers customer = new Customers { customer_name = "Black Hungary Kft" };
            Assert.That(() => customersController.Create(customer), Throws.TypeOf<ArgumentException>());
        }

        [Test]
        public void UpdatingInvoiceCurrency()
        {
            //ha a valuta változik az ár sem maradhatna, ezért nem szabad változtatni
            Invoices invoice =new Invoices {  invoice_nr = 1, price = 1093, currency = "USD" };
            Assert.That(() => invoicesController.Update("ObjectId('65291dad052c1b670ca89f13')", invoice), Throws.TypeOf<ArgumentException>());
        }      

        [Test]
        public void CreateOperatorsWithEmpty()
        {
            Operators operators = null;
            Assert.That(() => operatorsController.Create(operators), Throws.TypeOf<NullReferenceException>());
            
        }

        [Test]
        public void UpdateOrdersWithTooMuchPallet()
        {
            Orders order = new Orders { Id = "ObjectId('65291c09052c1b670c9e131c')", order_nr = 9000, customer_id = 4, temperature_name = "dry", palet_number = 81 };
            Assert.That(() => ordersController.Update("ObjectId('65291c09052c1b670c9e131c')", order), Throws.TypeOf<ArgumentException>());

        }

        [Test]
        public void CreatingRouteWithMoscow()
        {
            //nem lehet orosz
            Routes route = new Routes { destination = "Moscow", start_loc = "Budapest" };
            Assert.That(() => routesController.Create(route), Throws.TypeOf<ArgumentException>());

        }

        [Test]
        public void CreatingImpossibleTemperature()
        {
            //nem lehet lehetetlen hőfokot létrehozni
            Temperatures temp = new Temperatures { temperature_name = "freeze", celsius = 2, signal = "+" };
            Assert.That(() => temperaturesController.Create(temp), Throws.TypeOf<ArgumentException>());
        }

        [Test]
        public void UpdateTourWithWrongRoute()
        {
            //a háború miatt nincs szállítás kijevbe, ezért ezt le kell toiltani, ennek tesztelését az update metóduson fogom használni
            Tours tours = new Tours { Id = "ObjectId('65291c78052c1b670ca335eb')", TO_id = 3, carrier_id = 3, invoice_nr = 9003, order_nr = 3, route_id = 2, tour_end = new DateTime(2023, 12, 15) };
            Assert.That(() => toursController.Update("ObjectId('65291c78052c1b670ca335eb')", tours), Throws.TypeOf<ArgumentException>());
        }

        [Test]
        public void CreateTruckWithTooShortNrPlate() 
        {
            Trucks truck  = new Trucks { Id = "ObjectId('65291e40052c1b670cade50f')", trailer_nrplate="NH6752", country="Hungary", manufacturer="Ford", truck_nrplate="NH67", type="flatback"};
            Assert.That(() => trucksController.Create(truck), Throws.TypeOf<ArgumentException>());
        }

        

        

        

        


        

        












    }    
        

    
}