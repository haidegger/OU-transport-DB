﻿using MongoDB.Driver;
using transportdb.Models;

namespace transportdb.Services
{
    public interface IMongoDbService
    {
        //public IQueryable<Carriers> GetAllCarriers();
        //public void CreateCarriers(Carriers carrier);
        //public Carriers GetOneCarrier(string carrierid);
        //public void UpdateCarriers(string id, Carriers carrier);
        //public void DeleteCarriers(int id);
        public Task CreateCarriers(Carriers carrier);
        public Task<List<Carriers>> GetAllCarriers();
        public Task<Carriers> GetOneCarrier(string id);
        public Task UpdateCarriers(string id, Carriers carrier);
        public Task DeleteCarriers(string id);


        //public void CreateCustomers(Customers customer);
        //public Customers GetOneCustomer(string customerid);
        //public IQueryable<Customers> GetAllCustomers();
        //public void UpdateCustomers(string id, Customers customer);
        //public void DeleteCustomer(int id);

        public Task<Customers> GetOneCustomer(string id);
        public Task<List<Customers>> GetAllCustomers();
        public Task CreateCustomers(Customers customer);

        public Task UpdateCustomers(string id, Customers customer);

        public Task DeleteCustomers(string id);

        //public void CreateInvoices(Invoices invoice);
        //public Invoices GetOneInvoice(string invoiceid);
        //public IQueryable<Invoices> GetAllInvoices();
        //public void UpdateInvoices(string id, Invoices invoice);
        //public void DeleteInvoices(int id);

        public Task<Invoices> GetOneInvoice(string id);
        public Task<List<Invoices>> GetAllInvoices();
        public Task CreateInvoices(Invoices invoice);
        public Task UpdateInvoices(string id, Invoices invoice);
        public Task DeleteInvoices(string id);

        //public void CreateOperators(Operators to);
        //public Operators GetOneOperator(string operatorid);
        //public IQueryable<Operators> GetAllOperators();
        //public void UpdateOperators(string id, Operators to);
        //public void DeleteOperators(int id);

        public Task<Operators> GetOneOperator(string id);
        public Task<List<Operators>> GetAllOperators();
        public Task CreateOperators(Operators toperator);
        public Task UpdateOperators(string id, Operators toperator);
        public Task DeleteOperators(string id);

        //public void CreateOrders(Orders order);
        //public Orders GetOneOrder(string orderid);
        //public IQueryable<Orders> GetAllOrders();
        //public void UpdateOrders(string id, Orders order);
        //public void DeleteOrders(int id);

        public Task<Orders> GetOneOrder(string id);
        public Task<List<Orders>> GetAllOrders();
        public Task CreateOrders(Orders order);
        public Task UpdateOrders(string id, Orders order);
        public Task DeleteOrders(string id);

        //public void CreateRoutes(Routes route);
        //public Routes GetOneRoute(string routeid);
        //public IQueryable<Routes> GetAllRoutes();
        //public void UpdateRoutes(string id, Routes route);
        //public void DeleteRoutes(int id);

        public Task<Routes> GetOneRoute(string id);
        public Task<List<Routes>> GetAllRoutes();
        public Task CreateRoutes(Routes route);
        public Task UpdateRoutes(string id, Routes route);
        public Task DeleteRoutes(string id);

        //public void CreateTemperatures(Temperatures temperature);
        //public Temperatures GetOneTemperature(string temperatureid);
        //public IQueryable<Temperatures> GetAllTemperatures();
        //public void UpdateTemperatures(string id, Temperatures temperature);
        //public void DeleteTemperatures(string id);

        public Task<Temperatures> GetOneTemperature(string id);
        public Task<List<Temperatures>> GetAllTemperatures();
        public Task CreateTemperatures(Temperatures temperature);
        public Task UpdateTemperatures(string id, Temperatures temperature);
        public Task DeleteTemperatures(string id);

        //public void CreateTours(Tours tour);
        //public Tours GetOneTour(string tourid);
        //public IQueryable<Tours> GetAllTours();
        //public void UpdateTours(string id, Tours tour);
        //public void DeleteTours(int id);

        public Task<Tours> GetOneTour(string id);
        public Task<List<Tours>> GetAllTours();
        public Task CreateTours(Tours tour);
        public Task UpdateTours(string id, Tours tour);
        public Task DeleteTours(string id);

        //public void CreateTrailers(Trailers trailer);
        //public Trailers GetOneTrailer(string trailerid);
        //public IQueryable<Trailers> GetAllTrailers();
        //public void UpdateTrailers(string id, Trailers trailer);
        //public void DeleteTrailers(string id);

        public Task<Trailers> GetOneTrailer(string id);
        public Task<List<Trailers>> GetAllTrailers();
        public Task CreateTrailers(Trailers trailer);
        public Task UpdateTrailers(string id, Trailers trailer);
        public Task DeleteTrailers(string id);

        //public void CreateTrucks(Trucks truck);
        //public Trucks GetOneTruck(string truckid);
        //public IQueryable<Trucks> GetAllTrucks();
        //public void UpdateTrucks(string id, Trucks truck);
        //public void DeleteTrucks(string id);

        public Task<Trucks> GetOneTruck(string id);
        public Task<List<Trucks>> GetAllTrucks();
        public Task CreateTrucks(Trucks truck);
        public Task UpdateTrucks(string id, Trucks truck);
        public Task DeleteTrucks(string id);
    }
}
