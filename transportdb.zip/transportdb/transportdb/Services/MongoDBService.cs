﻿using transportdb.Models;
using Microsoft.Extensions.Options;
using MongoDB.Driver;
using MongoDB.Bson;
using transportdb.Controllers;

namespace transportdb.Services
{
    public class MongoDBService:IMongoDbService
    {
        private readonly IMongoCollection<Carriers> CarriersCollection;
        private readonly IMongoCollection<Customers> CustomersCollection;
        private readonly IMongoCollection<Invoices> InvoicesCollection;
        private readonly IMongoCollection<Operators> OperatorsCollection;
        private readonly IMongoCollection<Orders> OrdersCollection;
        private readonly IMongoCollection<Routes> RoutesCollection;
        private readonly IMongoCollection<Temperatures> TemperaturesCollection;
        private readonly IMongoCollection<Tours> ToursCollection;
        private readonly IMongoCollection<Trailers> TrailersCollection;
        private readonly IMongoCollection<Trucks> TrucksCollection;

        public MongoDBService(IOptions<MongoDbSetup> mongodbsettings)
        {
            MongoClient client = new MongoClient(mongodbsettings.Value.ConnectionURI);
            IMongoDatabase db = client.GetDatabase(mongodbsettings.Value.DatabaseName);
            CarriersCollection = db.GetCollection<Carriers>(mongodbsettings.Value.CollectionName="carriers");
            CustomersCollection = db.GetCollection<Customers>(mongodbsettings.Value.CollectionName="customers");
            InvoicesCollection = db.GetCollection<Invoices>(mongodbsettings.Value.CollectionName="invoices");
            OperatorsCollection = db.GetCollection<Operators>(mongodbsettings.Value.CollectionName="operators");
            OrdersCollection = db.GetCollection<Orders>(mongodbsettings.Value.CollectionName="orders");
            RoutesCollection = db.GetCollection<Models.Routes>(mongodbsettings.Value.CollectionName="routes");
            TemperaturesCollection = db.GetCollection<Temperatures>(mongodbsettings.Value.CollectionName="temperatures");
            ToursCollection = db.GetCollection<Tours>(mongodbsettings.Value.CollectionName="tours");
            TrailersCollection = db.GetCollection<Trailers>(mongodbsettings.Value.CollectionName="trailers");
            TrucksCollection = db.GetCollection<Trucks>(mongodbsettings.Value.CollectionName="trucks");
        }

        //carriers CRUD
        //public async Task CreateCarriers(Carriers carriers)
        //{
        //    await CarriersCollection.InsertOneAsync(carriers);
        //    return;
        //}

        //public async Task<List<Carriers>> GetAllCarriers()
        //{
        //    return await CarriersCollection.Find(new BsonDocument()).ToListAsync();
        //}

        //public async Task<Carriers> GetOneCarrier(int id)
        //{
        //    return await CarriersCollection.Find(x => x.carrier_id == id).FirstOrDefaultAsync();
        //}

        //public async Task UpdateCarriers(string id, Carriers updatedCarrier)
        //{
        //    await CarriersCollection.ReplaceOneAsync(x => x.Id == id, updatedCarrier);
        //    return;
        //}

        //public async Task DeleteCarriers(string id)
        //{
        //    FilterDefinition<Carriers> filter = Builders<Carriers>.Filter.Eq("Id", id);
        //    await CarriersCollection.DeleteOneAsync(filter);
        //    return;
        //}

        //public void CreateCarriers(Carriers carrier)
        //{
        //    CarriersCollection.InsertOne(carrier);

        //}
        //public void CreateCarriers(Carriers carrier)
        //{
        //    CarriersCollection.InsertOne(carrier);

        //}
        

        //public Carriers GetOneCarrier(string carrierid)
        //{
        //    return CarriersCollection.Find((x => x.Id == carrierid)).FirstOrDefault();
        //}

        public async Task<Carriers> GetOneCarrier(string id)
        {
            return await CarriersCollection.Find((x => x.Id == id)).FirstOrDefaultAsync();
        }

        //public IQueryable<Carriers> GetAllCarriers()
        //{
        //    return CarriersCollection.AsQueryable();
        //}

        public async Task<List<Carriers>> GetAllCarriers()
        {
            return await CarriersCollection.Find(x => true).ToListAsync();
        }

        public async Task CreateCarriers(Carriers carrier)
        {
            await CarriersCollection.InsertOneAsync(carrier);

        }

        //public void UpdateCarriers(string id, Carriers carrier)//csak egy mezőt enged módosítani, de működik
        //{
        //    var filter = Builders<Carriers>.Filter.Eq("Id", id);
        //    var update = Builders<Carriers>.Update.Set("first_name", carrier.first_name);
        //    CarriersCollection.UpdateOne(filter, update);


        //}

        public async Task UpdateCarriers(string id, Carriers carrier)
        {
            await CarriersCollection.ReplaceOneAsync(x => x.Id == id, carrier);
        }

        //public void DeleteCarriers(int id)
        //{
        //    CarriersCollection.DeleteOne(x => x.carrier_id == id);
        //}

        public async Task DeleteCarriers(string id)
        {
            await CarriersCollection.DeleteOneAsync(x => x.Id == id);
        }



        //Customers CRUD

        //public void CreateCustomers(Customers customer)
        //{
        //    CustomersCollection.InsertOne(customer);

        //}

        //public Customers GetOneCustomer(string customerid)
        //{
        //    return CustomersCollection.Find((x => x.Id == customerid)).FirstOrDefault();
        //}

        //public IQueryable<Customers> GetAllCustomers()
        //{
        //    return CustomersCollection.AsQueryable();
        //}

        //public void UpdateCustomers(string id, Customers customer)//csak egy mezőt enged módosítani, de működik
        //{
        //    var filter = Builders<Customers>.Filter.Eq("Id", id);
        //    var update = Builders<Customers>.Update.Set("customer_name", customer.customer_name);
        //    CustomersCollection.UpdateOne(filter, update);
        //}

        //public void DeleteCustomer(int id)
        //{
        //    CustomersCollection.DeleteOne(x => x.customer_id == id);
        //}

        public async Task<Customers> GetOneCustomer(string id)
        {
            return await CustomersCollection.Find((x => x.Id == id)).FirstOrDefaultAsync();
        }


        public async Task<List<Customers>> GetAllCustomers()
        {
            return await CustomersCollection.Find(x => true).ToListAsync();
        }

        public async Task CreateCustomers(Customers customer)
        {
            await CustomersCollection.InsertOneAsync(customer);

        }

        public async Task UpdateCustomers(string id, Customers customer)
        {
            await CustomersCollection.ReplaceOneAsync(x => x.Id == id, customer);
        }

        public async Task DeleteCustomers(string id)
        {
            await CustomersCollection.DeleteOneAsync(x => x.Id == id);
        }


        //Invoices CRUD
        //public void CreateInvoices(Invoices invoice)
        //{
        //    InvoicesCollection.InsertOne(invoice);

        //}

        //public Invoices GetOneInvoice(string invoiceid)
        //{
        //    return InvoicesCollection.Find((x => x.Id == invoiceid)).FirstOrDefault();
        //}

        //public IQueryable<Invoices> GetAllInvoices()
        //{
        //    return InvoicesCollection.AsQueryable();
        //}

        //public void UpdateInvoices(string id, Invoices invoice)//csak egy mezőt enged módosítani, de működik
        //{
        //    var filter = Builders<Invoices>.Filter.Eq("Id", id);
        //    var update = Builders<Invoices>.Update.Set("price", invoice.price);
        //    InvoicesCollection.UpdateOne(filter, update);
        //}

        //public void DeleteInvoices(int id)
        //{
        //    InvoicesCollection.DeleteOne(x => x.invoice_nr == id);
        //}

        public async Task<Invoices> GetOneInvoice(string id)
        {
            return await InvoicesCollection.Find((x => x.Id == id)).FirstOrDefaultAsync();
        }

        public async Task<List<Invoices>> GetAllInvoices()
        {
            return await InvoicesCollection.Find(x => true).ToListAsync();
        }

        public async Task CreateInvoices(Invoices invoice)
        {
            await InvoicesCollection.InsertOneAsync(invoice);

        }

        public async Task UpdateInvoices(string id, Invoices invoice)
        {
            await InvoicesCollection.ReplaceOneAsync(x => x.Id == id, invoice);
        }

        public async Task DeleteInvoices(string id)
        {
            await InvoicesCollection.DeleteOneAsync(x => x.Id == id);
        }



        //Operators CRUD


        //public IQueryable<Operators> GetAllOperators()
        //{
        //    return OperatorsCollection.AsQueryable();
        //}

        //public void UpdateOperators(string id, Operators to)
        //{
        //    var filter = Builders<Operators>.Filter.Eq("Id", id);
        //    var update = Builders<Operators>.Update.Set("first_name", to.first_name);
        //    OperatorsCollection.UpdateOne(filter, update);
        //}

        //public void DeleteOperators(int id)
        //{
        //    OperatorsCollection.DeleteOne(x => x.to_id == id);
        //}

        //ORDERS CRUD
        //public async Task CreateOrders(Orders order)
        //{
        //    await OrderCollection.InsertOneAsync(order);
        //    return;
        //}

        //public async Task<List<Orders>> GetAllOrders()
        //{
        //    return await OrderCollection.Find(new BsonDocument()).ToListAsync();
        //}

        //public async Task UpdateOrders(string id, string orderid)
        //{
        //    FilterDefinition<Orders> filter = Builders<Orders>.Filter.Eq("Id", id); //???
        //    UpdateDefinition<Orders> update = Builders<Orders>.Update.AddToSet<string>("orderId", orderid);
        //    await OrderCollection.UpdateOneAsync(filter, update);
        //    return;
        //}

        //public async Task DeleteOrders(string id)
        //{
        //    FilterDefinition<Orders> filter = Builders<Orders>.Filter.Eq("Id", id);
        //    await OrderCollection.DeleteOneAsync(filter);
        //    return;
        //}

        public async Task<Operators> GetOneOperator(string id)
        {
            return await OperatorsCollection.Find((x => x.Id == id)).FirstOrDefaultAsync();
        }

        public async Task<List<Operators>> GetAllOperators()
        {
            return await OperatorsCollection.Find(x => true).ToListAsync();
        }

        public async Task CreateOperators(Operators toperator)
        {
            await OperatorsCollection.InsertOneAsync(toperator);

        }

        public async Task UpdateOperators(string id, Operators toperator)
        {
            await OperatorsCollection.ReplaceOneAsync(x => x.Id == id, toperator);
        }

        public async Task DeleteOperators(string id)
        {
            await OperatorsCollection.DeleteOneAsync(x => x.Id == id);
        }

        //ORDERS CRUD
        //public void CreateOrders(Orders order)
        //{
        //    OrdersCollection.InsertOne(order);

        //}

        //public Orders GetOneOrder(string orderid)
        //{
        //    return OrdersCollection.Find((x => x.Id == orderid)).FirstOrDefault();
        //}

        //public IQueryable<Orders> GetAllOrders()
        //{
        //    return OrdersCollection.AsQueryable();
        //}

        //public void UpdateOrders(string id, Orders order)//csak egy mezőt enged módosítani, de működik
        //{
        //    var filter = Builders<Orders>.Filter.Eq("Id", id);
        //    var update = Builders<Orders>.Update.Set("temperature_name", order.temperature_name);
        //    OrdersCollection.UpdateOne(filter, update);


        //}

        //public void DeleteOrders(int id)
        //{
        //    OrdersCollection.DeleteOne(x => x.order_nr == id);
        //}

        public async Task<Orders> GetOneOrder(string id)
        {
            return await OrdersCollection.Find((x => x.Id == id)).FirstOrDefaultAsync();
        }

        public async Task<List<Orders>> GetAllOrders()
        {
            return await OrdersCollection.Find(x => true).ToListAsync();
        }

        public async Task CreateOrders(Orders order)
        {
            await OrdersCollection.InsertOneAsync(order);

        }

        public async Task UpdateOrders(string id, Orders order)
        {
            await OrdersCollection.ReplaceOneAsync(x => x.Id == id, order);
        }

        public async Task DeleteOrders(string id)
        {
            await OrdersCollection.DeleteOneAsync(x => x.Id == id);
        }


        //RoutesCRUD

        //public void CreateRoutes(Routes route)
        //{
        //    RoutesCollection.InsertOne(route);

        //}

        //public Routes GetOneRoute(string routeid)
        //{
        //    return RoutesCollection.Find((x => x.Id == routeid)).FirstOrDefault();
        //}

        //public IQueryable<Routes> GetAllRoutes()
        //{
        //    return RoutesCollection.AsQueryable();
        //}

        //public void UpdateRoutes(string id, Routes route)
        //{
        //    var filter = Builders<Routes>.Filter.Eq("Id", id);
        //    var update = Builders<Routes>.Update.Set("destination", route.destination);
        //    RoutesCollection.UpdateOne(filter, update);

        //}

        //public void DeleteRoutes(int id)
        //{
        //    RoutesCollection.DeleteOne(x => x.route_id == id);
        //}

        //Temperature CRUD
        //public async Task CreateTemperatures(Temperatures temperature)
        //{
        //    await TemperatureCollection.InsertOneAsync(temperature);
        //    return;
        //}

        //public async Task<List<Temperatures>> GetAllTemperatures()
        //{
        //    return await TemperatureCollection.Find(new BsonDocument()).ToListAsync();
        //}

        //public async Task UpdateTemperatures(string id, string temperatureid)
        //{
        //    FilterDefinition<Temperatures> filter = Builders<Temperatures>.Filter.Eq("Id", id); //???
        //    UpdateDefinition<Temperatures> update = Builders<Temperatures>.Update.AddToSet<string>("temperatureId", temperatureid);
        //    await TemperatureCollection.UpdateOneAsync(filter, update);
        //    return;
        //}

        //public async Task DeleteTemperatures(string id)
        //{
        //    FilterDefinition<Temperatures> filter = Builders<Temperatures>.Filter.Eq("Id", id);
        //    await TemperatureCollection.DeleteOneAsync(filter);
        //    return;
        //}

        public async Task<Routes> GetOneRoute(string id)
        {
            return await RoutesCollection.Find((x => x.Id == id)).FirstOrDefaultAsync();
        }

        public async Task<List<Routes>> GetAllRoutes()
        {
            return await RoutesCollection.Find(x => true).ToListAsync();
        }

        public async Task CreateRoutes(Routes route)
        {
            await RoutesCollection.InsertOneAsync(route);

        }

        public async Task UpdateRoutes(string id, Routes route)
        {
            await RoutesCollection.ReplaceOneAsync(x => x.Id == id, route);
        }

        public async Task DeleteRoutes(string id)
        {
            await RoutesCollection.DeleteOneAsync(x => x.Id == id);
        }

        //Temperatures CUD
        public async Task<Temperatures> GetOneTemperature(string id)
        {
            return await TemperaturesCollection.Find((x => x.Id == id)).FirstOrDefaultAsync();
        }

        public async Task<List<Temperatures>> GetAllTemperatures()
        {
            return await TemperaturesCollection.Find(x => true).ToListAsync();
        }

        public async Task CreateTemperatures(Temperatures temperature)
        {
            await TemperaturesCollection.InsertOneAsync(temperature);

        }

        public async Task UpdateTemperatures(string id, Temperatures temperature)
        {
            await TemperaturesCollection.ReplaceOneAsync(x => x.Id == id, temperature);
        }

        public async Task DeleteTemperatures(string id)
        {
            await TemperaturesCollection.DeleteOneAsync(x => x.Id == id);
        }


        //Tours CRUD
        //public void CreateTours(Tours tour)
        //{
        //    ToursCollection.InsertOne(tour);

        //}

        //public Tours GetOneTour(string tourid)
        //{
        //    return ToursCollection.Find((x => x.Id == tourid)).FirstOrDefault();
        //}

        //public IQueryable<Tours> GetAllTours()
        //{
        //    return ToursCollection.AsQueryable();
        //}

        //public void UpdateTours(string id, Tours tour)//csak egy mezőt enged módosítani, de működik
        //{
        //    var filter = Builders<Tours>.Filter.Eq("Id", id);
        //    var update = Builders<Tours>.Update.Set("order_nr", tour.order_nr);
        //    ToursCollection.UpdateOne(filter, update);


        //}

        //public void DeleteTours(int id)
        //{
        //    ToursCollection.DeleteOne(x => x.tour_nr == id);
        //}

        public async Task<Tours> GetOneTour(string id)
        {
            return await ToursCollection.Find((x => x.Id == id)).FirstOrDefaultAsync();
        }

        public async Task<List<Tours>> GetAllTours()
        {
            return await ToursCollection.Find(x => true).ToListAsync();
        }

        public async Task CreateTours(Tours tour)
        {
            await ToursCollection.InsertOneAsync(tour);

        }

        public async Task UpdateTours(string id, Tours tour)
        {
            await ToursCollection.ReplaceOneAsync(x => x.Id == id, tour);
        }

        public async Task DeleteTours(string id)
        {
            await ToursCollection.DeleteOneAsync(x => x.Id == id);
        }


        //Trailers CRUD

        //public void CreateTrailers(Trailers trailer)
        //{
        //    TrailersCollection.InsertOne(trailer);

        //}

        //public Trailers GetOneTrailer(string trailerid)
        //{
        //    return TrailersCollection.Find((x => x.Id == trailerid)).FirstOrDefault();
        //}

        //public IQueryable<Trailers> GetAllTrailers()
        //{
        //    return TrailersCollection.AsQueryable();
        //}

        //public void UpdateTrailers(string id, Trailers trailer)
        //{
        //    var filter = Builders<Trailers>.Filter.Eq("Id", id);
        //    var update = Builders<Trailers>.Update.Set("country", trailer.country);
        //    TrailersCollection.UpdateOne(filter, update);


        //}

        //public void DeleteTrailers(string id)//STRING!!
        //{
        //    TrailersCollection.DeleteOne(x => x.Id == id);
        //}

        

        public async Task<Trailers> GetOneTrailer(string id)
        {
            return await TrailersCollection.Find((x => x.Id == id)).FirstOrDefaultAsync();
        }

        public async Task<List<Trailers>> GetAllTrailers()
        {
            return await TrailersCollection.Find(x => true).ToListAsync();
        }

        public async Task CreateTrailers(Trailers trailer)
        {
            await TrailersCollection.InsertOneAsync(trailer);

        }

        public async Task UpdateTrailers(string id, Trailers trailer)
        {
            await TrailersCollection.ReplaceOneAsync(x => x.Id == id, trailer);
        }

        public async Task DeleteTrailers(string id)
        {
            await TrailersCollection.DeleteOneAsync(x => x.Id == id);
        }

        //Trucks CRUD

        //public void CreateTrucks(Trucks truck)
        //{
        //    TrucksCollection.InsertOne(truck);

        //}

        //public Trucks GetOneTruck(string truckid)
        //{
        //    return TrucksCollection.Find((x => x.Id == truckid)).FirstOrDefault();
        //}

        //public IQueryable<Trucks> GetAllTrucks()
        //{
        //    return TrucksCollection.AsQueryable();
        //}

        //public void UpdateTrucks(string id, Trucks truck)//csak egy mezőt enged módosítani, de működik
        //{
        //    var filter = Builders<Trucks>.Filter.Eq("Id", id);
        //    var update = Builders<Trucks>.Update.Set("manufacturer", truck.manufacturer);
        //    TrucksCollection.UpdateOne(filter, update);


        //}

        //public void DeleteTrucks(string id)//STRING!!
        //{
        //    TrucksCollection.DeleteOne(x => x.Id == id);
        //}

        public async Task<Trucks> GetOneTruck(string id)
        {
            return await TrucksCollection.Find((x => x.Id == id)).FirstOrDefaultAsync();
        }

        public async Task<List<Trucks>> GetAllTrucks()
        {
            return await TrucksCollection.Find(x => true).ToListAsync();
        }

        public async Task CreateTrucks(Trucks truck)
        {
            await TrucksCollection.InsertOneAsync(truck);

        }

        public async Task UpdateTrucks(string id, Trucks truck)
        {
            await TrucksCollection.ReplaceOneAsync(x => x.Id == id, truck);
        }

        public async Task DeleteTrucks(string id)
        {
            await TrucksCollection.DeleteOneAsync(x => x.Id == id);
        }

    }
}
