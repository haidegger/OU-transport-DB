﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using Realms;
using Realms.Schema;
using Realms.Weaving;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;


namespace transportdb.Models
{

    public partial class Carriers
    {

        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)] 
        public string? Id{ get; set; }
        
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int carrier_id { get; set; }
        public string first_name { get; set; }
        public string last_name { get; set; }
        public DateTime license_date { get; set; }
        public string truck_nrplate { get; set; }

      
    }

    public class Customers
    {

        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)] 
        public string? Id { get; set; }
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int customer_id { get; set;}
        public string customer_name { get; set; }
        public string contact { get; set; }
        public string city { get; set; }


    }

    public class Invoices
    {

        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)] 
        public string? Id { get; set; }
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int invoice_nr { get;set; }
        public int price {  get; set; } 
        public string currency { get; set; }


    }

    public class Operators
    {

        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)] 
        public string? Id { get; set; }
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int to_id { get;  set; }
        public string first_name { get; set; }
        public string last_name { get; set; }
        public DateTime start_date { get; set; }


    }

    public class Orders
    {

        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)] 
        public string? Id { get; set; }
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int order_nr { get; set;}
        public int customer_id { get; set;}
        public string temperature_name {  get; set; }
        public int palet_number { get; set; }


    }

    public class Routes
    {

        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)] 
        public string? Id { get; set; }
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int route_id {  get; set; }  
        public string start_loc { get; set; }
        public string destination { get; set;}


    }

    public class Temperatures
    {

        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)] 
        public string? Id { get; set; }
        public string temperature_name { get; set; }
        public int celsius { get; set; }
        public string signal { get; set; } 

    }

    public class Tours
    {

        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string? Id { get; set; }
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int tour_nr { get; set; }
        public int TO_id { get; set; }
        public int carrier_id { get;set; }
        public int route_id { get; set; }
        public int invoice_nr { get; set; }
        public int order_nr { get; set; }
        public DateTime tour_end { get; set; }

    }

    public class Trailers
    {

        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)] 
        public string? Id { get; set; }
        public string trailer_nrplate { get; set; }
        public string type { get; set; }
        public string country { get; set; }
    }

    public class Trucks
    {

        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)] 
        public string? Id { get; set; }
        public string truck_nrplate { get; set; }

        public string trailer_nrplate { get; set; }
        public string manufacturer { get; set; }
        public string type { get; set; }
        public string country { get; set; }
    }
}
