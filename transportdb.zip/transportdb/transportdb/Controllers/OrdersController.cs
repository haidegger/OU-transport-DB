﻿using Microsoft.AspNetCore.Mvc;
using System.Threading;
using transportdb.Models;
using transportdb.Services;

namespace transportdb.Controllers
{
    [Controller]
    [Route("[controller]")]
    public class OrdersController : Controller // mi az a controller
    {
        IMongoDbService _dbService;

        public OrdersController(IMongoDbService mongoDBService)
        {
            _dbService = mongoDBService;
        }

        //*************************************************ORDERS CRUD********************************************************************

        //[HttpGet]
        //public IQueryable<Orders> ReadAll()
        //{
        //    return _dbService.GetAllOrders();

        //}

        //[HttpGet("{id}")]
        //public Orders ReadOne(string id)
        //{
        //    return _dbService.GetOneOrder(id);

        //}

        //[HttpPost]
        //public void Create([FromBody] Orders order)
        //{
        //    if (order == null)
        //    {
        //        throw new NullReferenceException();
        //    }
        //    _dbService.CreateOrders(order);
        //}

        //[HttpPut("{id}")]
        //public void Update(string id, [FromBody] Orders updatedOrder)
        //{

        //    if (updatedOrder.palet_number>80)
        //    {
        //        throw new ArgumentException("Too much pallets");
        //    }
        //    _dbService.UpdateOrders(id, updatedOrder);
        //}

        //[HttpDelete]
        //public void Delete(int id)
        //{

        //    _dbService.DeleteOrders(id);

        //}
       
        [HttpGet]
        public async Task<List<Orders>> GetAll()
        {
            return await _dbService.GetAllOrders();

        }

        [HttpGet("{id}")]
        public async Task<Orders> GetOne(string id)
        {
            return await _dbService.GetOneOrder(id);

        }

        [HttpPost]
        public async Task<IActionResult> Create([FromBody] Orders carrier)
        {
            if (carrier == null)
            {
                throw new NullReferenceException();
            }

            await _dbService.CreateOrders(carrier);
            return CreatedAtAction(nameof(Create), new { id = carrier.Id }, carrier);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Update(string id, [FromBody] Orders updatedOrder)
        {
            if (updatedOrder.palet_number > 80)
            {
                throw new ArgumentException("Too much pallets");
            }
            await _dbService.UpdateOrders(id, updatedOrder);
            return NoContent();

        }

        [Route("{id}")]
        [HttpDelete]
        public async Task<IActionResult> Delete(string id)
        {
            await _dbService.DeleteOrders(id);
            return NoContent();

        }

    }
}
