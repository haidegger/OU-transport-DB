﻿using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using transportdb.Models;
using transportdb.Services;

namespace transportdb.Controllers
{
    [Controller]
    [Route("[controller]")]
    public class TrailersController : Controller // mi az a controller
    {
        IMongoDbService _dbService;

        public TrailersController(IMongoDbService mongoDBService)
        {
            _dbService = mongoDBService;
        }

        //*************************************************TRAILERS CRUD********************************************************************

        //[HttpGet]
        //public IQueryable<Trailers> GetAll()
        //{
        //    return  _dbService.GetAllTrailers();

        //}

        //[HttpGet("{id}")]
        //public Trailers ReadOne(string id)
        //{
        //    return _dbService.GetOneTrailer(id);

        //}
        //[HttpPost]
        //public void Create([FromBody] Trailers trailer) 
        //{
        //    if (trailer == null)
        //    {
        //        throw new NullReferenceException();
        //    }
        //    else if (trailer.trailer_nrplate.Length < 6)
        //    {
        //        throw new ArgumentException("Numberplate must contain 6 letters/numbers");
        //    }
        //    _dbService.CreateTrailers(trailer);

        //}

        //[HttpPut("{id}")]
        //public void Update(string id, [FromBody] Trailers updatedTrailer)
        //{

        //     _dbService.UpdateTrailers(id, updatedTrailer);


        //}

        //[HttpDelete]
        //public void Delete(string id)
        //{
        //     _dbService.DeleteTrailers(id);


        //}

        [HttpGet]
        public async Task<List<Trailers>> GetAll()
        {
            return await _dbService.GetAllTrailers();

        }

        [HttpGet("{id}")]
        public async Task<Trailers> GetOne(string id)
        {
            return await _dbService.GetOneTrailer(id);

        }

        [HttpPost]
        public async Task<IActionResult> Create([FromBody] Trailers trailer)
        {
            if (trailer == null)
            {
                throw new NullReferenceException();
            }

            await _dbService.CreateTrailers(trailer);
            return CreatedAtAction(nameof(Create), new { id = trailer.Id }, trailer);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Update(string id, [FromBody] Trailers updatedTrailer)
        {

            await _dbService.UpdateTrailers(id, updatedTrailer);
            return NoContent();

        }

        [Route("{id}")]
        [HttpDelete]
        public async Task<IActionResult> Delete(string id)
        {
            await _dbService.DeleteTrailers(id);
            return NoContent();

        }

    }
}
