﻿using Microsoft.AspNetCore.Mvc;
using System.Threading;
using transportdb.Models;
using transportdb.Services;

namespace transportdb.Controllers
{

    [Controller]
    [Route("[controller]")]
    public class CustomersController : Controller
    {
        private readonly IMongoDbService _dbService;

        public CustomersController(IMongoDbService mongoDBService)
        {
            _dbService = mongoDBService;
        }

        //************************************************CUSTOMERS CRUD********************************************************************


        //[HttpGet]
        //public IQueryable<Customers> ReadAll()
        //{
        //    return _dbService.GetAllCustomers();
        //}

        //[HttpGet("{id}")]
        //public Customers ReadOne(string id)
        //{
        //    return _dbService.GetOneCustomer(id);

        //}

        //[HttpPost]
        //public void Create([FromBody] Customers customer) // FromBody??
        //{
        //    if (customer == null)
        //    {
        //        throw new NullReferenceException();
        //    }
        //    else if (customer.customer_name.Contains("Black Hungary"))
        //    {
        //        throw new ArgumentException("This customer is blacklisted!");
        //    }
        //    _dbService.CreateCustomers(customer);
        //}

        //[HttpPut("{id}")]
        //public void UpdateCustomers(string id, [FromBody] Customers updatedCustomer)
        //{
        //    _dbService.UpdateCustomers(id, updatedCustomer);

        //}

        //[HttpDelete]
        //public void DeleteCustomers(int id)
        //{
        //   _dbService.DeleteCustomer(id);


        //}

        [HttpGet]
        public async Task<List<Customers>> GetAll()
        {
            return await _dbService.GetAllCustomers();

        }

        [HttpGet("{id}")]
        public async Task<Customers> GetOne(string id)
        {
            return await _dbService.GetOneCustomer(id);

        }

        [HttpPost]
        public async Task<IActionResult> Create([FromBody] Customers customer)
        {
            if (customer == null)
            {
                throw new NullReferenceException();
            }
            else if (customer.customer_name.Contains("Black Hungary"))
            {
                throw new ArgumentException("This customer is blacklisted!");
            }
            await _dbService.CreateCustomers (customer);
            return CreatedAtAction(nameof(Create), new { id = customer.Id }, customer);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Update(string id, [FromBody] Customers updatedCustomer)
        {

            await _dbService.UpdateCustomers(id, updatedCustomer);
            return NoContent();

        }

        [Route("{id}")]
        [HttpDelete]
        public async Task<IActionResult> Delete(string id)
        {
            await _dbService.DeleteCustomers(id);
            return NoContent();

        }


    }
}
