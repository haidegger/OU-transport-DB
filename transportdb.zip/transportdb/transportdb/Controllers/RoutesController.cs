﻿using Microsoft.AspNetCore.Mvc;
using transportdb.Models;
using transportdb.Services;

namespace transportdb.Controllers
{
    [Controller]
    [Route("[controller]")]
    public class RoutesController : Controller // mi az a controller
    {
        IMongoDbService _dbService;

        public RoutesController(IMongoDbService mongoDBService)
        {
            _dbService = mongoDBService;
        }

        //*************************************************ROUTES CRUD********************************************************************

        //[HttpGet]
        //public IQueryable<Routes> GetAll()
        //{
        //    return _dbService.GetAllRoutes();

        //}

        //[HttpGet("{id}")]
        //public Routes ReadOne(string id)
        //{
        //    return _dbService.GetOneRoute(id);

        //}

        //[HttpPost]
        //public void Create([FromBody] Routes route)
        //{
        //    if (route == null)
        //    {
        //        throw new NullReferenceException();
        //    }
        //    else if (route.destination=="Moscow" || route.start_loc=="Moscow")
        //    {
        //        throw new ArgumentException("Cannot go to Russia due to wars!");
        //    }
        //    _dbService.CreateRoutes(route);
        //}

        //[HttpPut("{id}")]//Update
        //public void Update(string id, [FromBody] Routes updatedRoute)
        //{
        //    _dbService.UpdateRoutes(id, updatedRoute);

        //}

        //[HttpDelete]
        //public void Delete(int id)
        //{
        //     _dbService.DeleteRoutes(id);

        //}

        [HttpGet]
        public async Task<List<Routes>> GetAll()
        {
            return await _dbService.GetAllRoutes();

        }

        [HttpGet("{id}")]
        public async Task<Routes> GetOne(string id)
        {
            return await _dbService.GetOneRoute(id);

        }

        [HttpPost]
        public async Task<IActionResult> Create([FromBody] Routes route)
        {
            if (route == null)
            {
                throw new NullReferenceException();
            }
            else if (route.destination == "Moscow" || route.start_loc == "Moscow")
            {
                throw new ArgumentException("Cannot go to Russia due to wars!");
            }

            await _dbService.CreateRoutes(route);
            return CreatedAtAction(nameof(Create), new { id = route.Id }, route);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Update(string id, [FromBody] Routes updatedRoute)
        {

            await _dbService.UpdateRoutes(id, updatedRoute);
            return NoContent();

        }

        [Route("{id}")]
        [HttpDelete]
        public async Task<IActionResult> Delete(string id)
        {
            await _dbService.DeleteRoutes(id);
            return NoContent();

        }

    }
}
