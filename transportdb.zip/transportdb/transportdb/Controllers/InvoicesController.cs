﻿using Microsoft.AspNetCore.Mvc;
using System.Threading;
using transportdb.Models;
using transportdb.Services;

namespace transportdb.Controllers
{
    [Controller]
    [Route("[controller]")]
    public class InvoicesController:Controller
    {
        IMongoDbService _dbService;

        public InvoicesController(IMongoDbService mongoDBService)
        {
            _dbService = mongoDBService;
        }

        //*************************************************INVOICES CRUD********************************************************************

        //[HttpGet]
        //public IQueryable<Invoices> ReadAll()
        //{
        //    return _dbService.GetAllInvoices();

        //}

        //[HttpGet("{id}")]
        //public Invoices ReadOne(string id)
        //{
        //    return _dbService.GetOneInvoice(id);

        //}

        //[HttpPost]
        //public void Create([FromBody] Invoices invoice) 
        //{
        //    if (invoice == null)
        //    {
        //        throw new NullReferenceException();
        //    }
        //    _dbService.CreateInvoices(invoice);
        //}

        //[HttpPut("{id}")]
        //public void Update(string id, [FromBody] Invoices updatedInvoice)
        //{
        //    if (updatedInvoice.currency!="EUR" && updatedInvoice.currency != "HUF" && updatedInvoice.currency != "GBP")
        //    {
        //        throw new ArgumentException("Can't modify it.");
        //    }
        //    _dbService.UpdateInvoices(id, updatedInvoice);

        //}

        //[HttpDelete]
        //public void Delete(int id)
        //{
        //    _dbService.DeleteInvoices(id);

        //}
        [HttpGet]
        public async Task<List<Invoices>> GetAll()
        {
            return await _dbService.GetAllInvoices();

        }

        [HttpGet("{id}")]
        public async Task<Invoices> GetOne(string id)
        {
            return await _dbService.GetOneInvoice(id);

        }

        [HttpPost]
        public async Task<IActionResult> Create([FromBody] Invoices invoice)
        {
            if (invoice == null)
            {
                throw new NullReferenceException();
            }

            await _dbService.CreateInvoices(invoice);
            return CreatedAtAction(nameof(Create), new { id = invoice.Id }, invoice);
        }

        [HttpPut("{id}")]//Update
        public async Task<IActionResult> Update(string id, [FromBody] Invoices updatedInvoice)
        {
            if (updatedInvoice.currency != "EUR" && updatedInvoice.currency != "HUF" && updatedInvoice.currency != "GBP")
            {
                throw new ArgumentException("Can't modify it.");
            }
            await _dbService.UpdateInvoices(id, updatedInvoice);
            return NoContent();

        }

        [Route("{id}")]
        [HttpDelete]
        public async Task<IActionResult> Delete(string id)
        {
            await _dbService.DeleteInvoices(id);
            return NoContent();

        }

    }
}
