﻿using System;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using transportdb.Models;
using transportdb.Services;


namespace transportdb.Controllers
{
    [Controller]
    [Route("[controller]")]
    public class CarriersController : Controller // mi az a controller
    {
        IMongoDbService _dbService;

        public CarriersController(IMongoDbService mongoDBService)
        {
            _dbService = mongoDBService;
        }

        [HttpGet]
        public async Task<List<Carriers>> GetAllAsync()
        {
            return await _dbService.GetAllCarriers();

        }

        //[HttpGet]
        //public IQueryable<Carriers> ReadAll()
        //{
        //    return _dbService.GetAllCarriers();

        //}

        [HttpGet("{id}")]
        public async Task<Carriers> GetOne(string id)
        {
            return await _dbService.GetOneCarrier(id);

        }

        //[HttpGet("{id}")]
        //public Carriers ReadOne(string id)
        //{
        //    return _dbService.GetOneCarrier(id);

        //}

        [HttpPost]
        public async Task<IActionResult> Create([FromBody] Carriers carrier) // FromBody??
        {
            if (carrier == null)
            {
                throw new NullReferenceException();
            }
            else if (carrier.license_date < DateTime.Today)
            {
                throw new ArgumentException("Cannot create carrier with expired license!");
            }
            await _dbService.CreateCarriers(carrier);
            return CreatedAtAction(nameof(Create), new { id = carrier.Id }, carrier);
        }

        //[HttpPost]
        //public void Create([FromBody]Carriers carrier)
        //{
        //    if (carrier == null)
        //    {
        //        throw new NullReferenceException();
        //    }
        //    else if (carrier.license_date<DateTime.Today)
        //    {
        //        throw new ArgumentException("Cannot create carrier with expired license!");
        //    }
        //    _dbService.CreateCarriers(carrier);
        //}

        [HttpPut("{id}")]//Update
        public async Task<IActionResult> Update(string id, [FromBody] Carriers updatedCarrier)
        {
            await _dbService.UpdateCarriers(id, updatedCarrier);
            return NoContent();

        }

        //[HttpPut("{id}")]
        //public void Update(string id, [FromBody] Carriers updatedCarrier)
        //{
        //    if (updatedCarrier.first_name == "Disney")
        //    {
        //        throw new ArgumentException("He was banned");
        //    }
        //    _dbService.UpdateCarriers(id, updatedCarrier);


        //}
        [Route("{id}")]
        [HttpDelete]
        public async Task<IActionResult> Delete(string id)
        {
            await _dbService.DeleteCarriers(id);
            return NoContent();

        }

        //[HttpDelete]
        //public void Delete(int id)
        //{
        //    _dbService.DeleteCarriers(id);


        //}



    }
}

    

    

    

    
