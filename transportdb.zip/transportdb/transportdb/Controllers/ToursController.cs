﻿using Microsoft.AspNetCore.Mvc;
using transportdb.Models;
using transportdb.Services;

namespace transportdb.Controllers
{
    [Controller]
    [Route("[controller]")]
    public class ToursController : Controller 
    {
        IMongoDbService _dbService;

        public ToursController(IMongoDbService mongoDBService)
        {
            _dbService = mongoDBService;
        }

        //*************************************************TOURS CRUD********************************************************************

        //[HttpGet]
        //public IQueryable<Tours> GetAll()
        //{
        //    return  _dbService.GetAllTours();

        //}

        //[HttpGet("{id}")]
        //public Tours ReadOne(string id)
        //{
        //    return _dbService.GetOneTour(id);

        //}

        //[HttpPost]
        //public void Create([FromBody] Tours tour) // FromBody??
        //{
        //    if (tour==null)
        //    {
        //        throw new NullReferenceException();
        //    }

        //    _dbService.CreateTours(tour);
        //}

        //[HttpPut("{id}")]
        //public void Update(string id, [FromBody] Tours updatedTour)
        //{
        //    if(updatedTour.route_id==2)
        //    {
        //        throw new ArgumentException("Cannot go there");
        //    }
        //    _dbService.UpdateTours(id, updatedTour);

        //}

        //[HttpDelete]
        //public void Delete(int id)
        //{
        //    _dbService.DeleteTours(id);


        //}

        [HttpGet]
        public async Task<List<Tours>> GetAll()
        {
            return await _dbService.GetAllTours();

        }

        [HttpGet("{id}")]
        public async Task<Tours> GetOne(string id)
        {
            return await _dbService.GetOneTour(id);

        }

        [HttpPost]
        public async Task<IActionResult> Create([FromBody] Tours tour)
        {
            if (tour == null)
            {
                throw new NullReferenceException();
            }

            await _dbService.CreateTours(tour);
            return CreatedAtAction(nameof(Create), new { id = tour.Id }, tour);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Update(string id, [FromBody] Tours updatedTour)
        {
            if (updatedTour.route_id == 2)
            {
                throw new ArgumentException("Cannot go there");
            }
            await _dbService.UpdateTours(id, updatedTour);
            return NoContent();

        }

        [Route("{id}")]
        [HttpDelete]
        public async Task<IActionResult> Delete(string id)
        {
            await _dbService.DeleteTours(id);
            return NoContent();

        }

    }
}
