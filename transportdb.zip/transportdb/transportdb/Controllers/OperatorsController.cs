﻿using Microsoft.AspNetCore.Mvc;
using System.Threading;
using transportdb.Models;
using transportdb.Services;

namespace transportdb.Controllers
{
    [Controller]
    [Route("[controller]")]
    public class OperatorsController : Controller // mi az a controller
    {
        private readonly IMongoDbService _dbService;

        public OperatorsController(IMongoDbService mongoDBService)
        {
            _dbService = mongoDBService;
        }

        //*************************************************OPERATORS CRUD********************************************************************

        //[HttpGet]
        //public IQueryable<Operators> GetAll()
        //{
        //    return  _dbService.GetAllOperators();

        //}

        //[HttpGet("{id}")]
        //public Operators ReadOne(string id)
        //{
        //    return _dbService.GetOneOperator(id);

        //}

        //[HttpPost]
        //public void Create([FromBody] Operators toperator) 
        //{
        //    if (toperator == null)
        //    {
        //        throw new NullReferenceException();
        //    }
        //    _dbService.CreateOperators(toperator);
        //}

        //[HttpPut("{id}")]
        //public void Update(string id, [FromBody] Operators updatedOperator)
        //{
        //    _dbService.UpdateOperators(id, updatedOperator);

        //}

        //[HttpDelete]
        //public void Delete(int id)
        //{
        //    _dbService.DeleteOperators(id);


        //}

        [HttpGet]
        public async Task<List<Operators>> GetAll()
        {
            return await _dbService.GetAllOperators();

        }

        [HttpGet("{id}")]
        public async Task<Operators> GetOne(string id)
        {
            return await _dbService.GetOneOperator(id);

        }

        [HttpPost]
        public async Task<IActionResult> Create([FromBody] Operators toperator)
        {
            if (toperator == null)
            {
                throw new NullReferenceException();
            }

            await _dbService.CreateOperators(toperator);
            return CreatedAtAction(nameof(Create), new { id = toperator.Id }, toperator);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Update(string id, [FromBody] Operators updatedOperator)
        {

            await _dbService.UpdateOperators(id, updatedOperator);
            return NoContent();

        }

        [Route("{id}")]
        [HttpDelete]
        public async Task<IActionResult> Delete(string id)
        {
            await _dbService.DeleteOperators(id);
            return NoContent();

        }



    }
}
