﻿using Microsoft.AspNetCore.Mvc;
using System.Threading;
using transportdb.Models;
using transportdb.Services;

namespace transportdb.Controllers
{
    [Controller]
    [Route("[controller]")]
    public class TemperaturesController : Controller // mi az a controller
    {
        IMongoDbService _dbService;

        public TemperaturesController(IMongoDbService mongoDBService)
        {
            _dbService = mongoDBService;
        }

        //*************************************************TEMPERATURES CRUD********************************************************************

        //[HttpGet]
        //public IQueryable GetAll()
        //{
        //    return _dbService.GetAllTemperatures();

        //}

        //[HttpGet("{id}")]
        //public Temperatures ReadOne(string id)
        //{
        //    return _dbService.GetOneTemperature(id);

        //}

        //[HttpPost]
        //public void Create([FromBody] Temperatures temperature) 
        //{
        //    if (temperature == null)
        //    {
        //        throw new NullReferenceException();
        //    }
        //    else if (temperature.temperature_name=="freeze" && temperature.signal=="+")
        //    {
        //        throw new ArgumentException("A + signal is impossible for a freezing temperature!");
        //    }
        //    _dbService.CreateTemperatures(temperature);
        //}

        //[HttpPut("{id}")]
        //public void Update(string id, [FromBody] Temperatures updatedTemperature)
        //{
        //    _dbService.UpdateTemperatures(id, updatedTemperature);


        //}

        //[HttpDelete]
        //public void Delete(string id)
        //{
        //    _dbService.DeleteTemperatures(id);

        //}

        [HttpGet]
        public async Task<List<Temperatures>> GetAll()
        {
            return await _dbService.GetAllTemperatures();

        }

        [HttpGet("{id}")]
        public async Task<Temperatures> GetOne(string id)
        {
            return await _dbService.GetOneTemperature(id);

        }

        [HttpPost]
        public async Task<IActionResult> Create([FromBody] Temperatures temperature)
        {
            if (temperature == null)
            {
                throw new NullReferenceException();
            }
            else if (temperature.temperature_name == "freeze" && temperature.signal == "+")
            {
                throw new ArgumentException("+ signal is impossible for a freezing temperature!");
            }

            await _dbService.CreateTemperatures(temperature);
            return CreatedAtAction(nameof(Create), new { id = temperature.Id }, temperature);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Update(string id, [FromBody] Temperatures updatedTemperature)
        {

            await _dbService.UpdateTemperatures(id, updatedTemperature);
            return NoContent();

        }

        [Route("{id}")]
        [HttpDelete]
        public async Task<IActionResult> Delete(string id)
        {
            await _dbService.DeleteTemperatures(id);
            return NoContent();

        }

    }
}
