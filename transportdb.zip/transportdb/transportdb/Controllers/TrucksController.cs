﻿using Microsoft.AspNetCore.Mvc;
using transportdb.Models;
using transportdb.Services;

namespace transportdb.Controllers
{
    [Controller]
    [Route("[controller]")]
    public class TrucksController : Controller // mi az a controller
    {
        private readonly IMongoDbService _dbService;

        public TrucksController(IMongoDbService mongoDBService)
        {
            _dbService = mongoDBService;
        }

        //*************************************************TRUCKS CRUD********************************************************************

        //[HttpGet]
        //public IQueryable<Trucks> GetAll()
        //{
        //    return  _dbService.GetAllTrucks();

        //}

        //[HttpGet("{id}")]
        //public Trucks ReadOne(string id)
        //{
        //    return _dbService.GetOneTruck(id);

        //}

        //[HttpPost]
        //public void Create([FromBody] Trucks truck) // FromBody??
        //{
        //    if (truck==null)
        //    {
        //        throw new NullReferenceException();
        //    }
        //    else if (truck.truck_nrplate.Length<6)
        //    {
        //        throw new ArgumentException("Not enough");
        //    }        
        //    _dbService.CreateTrucks(truck);
        //}

        //[HttpPut("{id}")]//Update
        //public void Update(string id, [FromBody] Trucks updatedTrucks)
        //{
        //     _dbService.UpdateTrucks(id, updatedTrucks);

        //}

        //[HttpDelete]
        //public void Delete(string id)
        //{
        //    _dbService.DeleteTrucks(id);


        //}

        [HttpGet]
        public async Task<List<Trucks>> GetAll()
        {
            return await _dbService.GetAllTrucks();

        }

        [HttpGet("{id}")]
        public async Task<Trucks> GetOne(string id)
        {
            return await _dbService.GetOneTruck(id);

        }

        [HttpPost]
        public async Task<IActionResult> Create([FromBody] Trucks truck)
        {
            if (truck == null)
            {
                throw new NullReferenceException();
            }
            else if (truck.truck_nrplate.Length < 6)
            {
                throw new ArgumentException("Not enough");
            }

            await _dbService.CreateTrucks(truck);
            return CreatedAtAction(nameof(Create), new { id = truck.Id }, truck);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Update(string id, [FromBody] Trucks updatedTruck)
        {

            await _dbService.UpdateTrucks(id, updatedTruck);
            return NoContent();

        }

        [Route("{id}")]
        [HttpDelete]
        public async Task<IActionResult> Delete(string id)
        {
            await _dbService.DeleteTrucks(id);
            return NoContent();

        }

    }
}
