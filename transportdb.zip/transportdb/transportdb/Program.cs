using transportdb.Models;
using transportdb.Services;

var builder = WebApplication.CreateBuilder(args);
builder.Services.Configure<MongoDbSetup>(builder.Configuration.GetSection("MongoDB")); //Mit csin�l?????- MongoDB appsetting.json section, amibe benn vannak az datok

builder.Services.AddSingleton<MongoDBService>();
builder.Services.AddScoped<IMongoDbService, MongoDBService>();//�n adtam hozz�, hogy tesztn�l is m�k�dj�n, �s swaggerben is

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

builder.Services.AddMvc(options =>
{
    options.SuppressAsyncSuffixInActionNames = false;
});

var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
