﻿using transportdb.Models;

namespace Repository
{
    public interface ICarrierRepository
    {
        void Create(Carriers singer);

        Carriers Read(int id);

        IQueryable<Carriers> ReadAll();

        void Update(Carriers carrier);

        public void Delete(int id);
    }
}