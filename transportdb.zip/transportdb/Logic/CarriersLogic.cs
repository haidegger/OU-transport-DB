﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Logic
{
    internal class CarriersLogic
    {
        void Create(Singer singer);
        Singer Read(int id);

        IQueryable<Singer> ReadAll();

        void Update(Singer singer);

        public void Delete(int id);
    }
}
