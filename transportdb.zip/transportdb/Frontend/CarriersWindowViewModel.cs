﻿using Microsoft.Extensions.Options;
using Microsoft.Toolkit.Mvvm.ComponentModel;
using Microsoft.Toolkit.Mvvm.Input;
using MongoDB.Driver;
using Realms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using transportdb.Controllers;
using transportdb.Frontend;
using transportdb.Models;
using transportdb.Services;

namespace Frontend
{
    public class CarriersWindowViewModel:ObservableRecipient
    {
        public RestCollection<Carriers> Carriers { get; set; }
        private Carriers selectedCarrier;
        public Carriers SelectedCarrier 
        { 
            get { return selectedCarrier; } 
            set 
            {
                if (value!=null)
                {
                    selectedCarrier = new Carriers()
                    {
                        Id = value.Id,
                        carrier_id = value.carrier_id,
                        first_name = value.first_name,
                        last_name = value.last_name,
                        license_date = value.license_date,
                        truck_nrplate = value.truck_nrplate
                    };
                }
                OnPropertyChanged();
                (DeleteCommand as RelayCommand).NotifyCanExecuteChanged();
                (UpdateCommand as RelayCommand).NotifyCanExecuteChanged();
                (CreateCommand as RelayCommand).NotifyCanExecuteChanged();
            } 
        }

        public ICommand CreateCommand { get; set; }
        public ICommand DeleteCommand { get; set; }
        public ICommand UpdateCommand { get; set; }

        public static bool IsInDesignMode
        {
            get
            {
                var prop = DesignerProperties.IsInDesignModeProperty;
                return (bool)DependencyPropertyDescriptor.FromProperty(prop, typeof(FrameworkElement)).Metadata.DefaultValue;
            }
        }
        public CarriersWindowViewModel()
        {

            if (!IsInDesignMode)
            {
                Carriers = new RestCollection<Carriers>("https://localhost:7188/", "carriers");  
                
            }

            CreateCommand = new RelayCommand(() =>
            {                
                Carriers.Add(new Carriers
                {
                    carrier_id=SelectedCarrier.carrier_id,
                    first_name=SelectedCarrier.first_name,
                    last_name=SelectedCarrier.last_name,
                    license_date=SelectedCarrier.license_date,
                    truck_nrplate=SelectedCarrier.truck_nrplate
                });
            },
            () =>
            {
                return SelectedCarrier != null;
            });

            DeleteCommand = new RelayCommand(() =>
            {
                Carriers.Delete(SelectedCarrier.Id);
            },
            () =>
            {
                return SelectedCarrier != null;
            });

            UpdateCommand = new RelayCommand(() =>
            {
                Carriers.Update(SelectedCarrier, SelectedCarrier.Id);
            },
            () =>
            {
                return SelectedCarrier != null;
            });

        }

        
    }
}
