﻿using Microsoft.Toolkit.Mvvm.Input;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using System.Windows;
using transportdb.Frontend;
using transportdb.Models;
using Microsoft.Toolkit.Mvvm.ComponentModel;

namespace Frontend
{
    class TrucksWindowViewModel:ObservableRecipient
    {
        public RestCollection<Trucks> Trucks { get; set; }
        private Trucks selectedTruck;
        public Trucks SelectedTruck

        {
            get { return selectedTruck; }
            set
            {
                if (value != null)
                {
                    selectedTruck = new Trucks()
                    {
                        Id = value.Id,
                        truck_nrplate=value.truck_nrplate,
                        trailer_nrplate=value.trailer_nrplate,
                        type=value.type,
                        country=value.country,
                        manufacturer=value.manufacturer
                    };
                }
                OnPropertyChanged();
                (DeleteCommand as RelayCommand).NotifyCanExecuteChanged();
                (UpdateCommand as RelayCommand).NotifyCanExecuteChanged();
                (CreateCommand as RelayCommand).NotifyCanExecuteChanged();
            }
        }

        public ICommand CreateCommand { get; set; }
        public ICommand DeleteCommand { get; set; }
        public ICommand UpdateCommand { get; set; }

        public static bool IsInDesignMode
        {
            get
            {
                var prop = DesignerProperties.IsInDesignModeProperty;
                return (bool)DependencyPropertyDescriptor.FromProperty(prop, typeof(FrameworkElement)).Metadata.DefaultValue;
            }
        }
        public TrucksWindowViewModel()
        {

            if (!IsInDesignMode)
            {
                Trucks = new RestCollection<Trucks>("https://localhost:7188/", "trucks");

            }

            CreateCommand = new RelayCommand(() =>
            {
                Trucks.Add(new Trucks
                {
                    truck_nrplate = SelectedTruck.truck_nrplate,
                    trailer_nrplate = SelectedTruck.trailer_nrplate,
                    type = SelectedTruck.type,
                    country = SelectedTruck.country,
                    manufacturer = SelectedTruck.manufacturer
                });
            },
            () =>
            {
                return SelectedTruck != null;
            });

            DeleteCommand = new RelayCommand(() =>
            {
                Trucks.Delete(SelectedTruck.Id);
            },
            () =>
            {
                return SelectedTruck != null;
            });

            UpdateCommand = new RelayCommand(() =>
            {
                Trucks.Update(SelectedTruck, SelectedTruck.Id);
            },
            () =>
            {
                return SelectedTruck != null;
            });

        }
    }
}
