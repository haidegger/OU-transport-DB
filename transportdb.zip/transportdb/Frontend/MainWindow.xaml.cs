﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using transportdb.Frontend;
using transportdb.Models;

namespace Frontend
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            this.WindowStartupLocation = WindowStartupLocation.CenterScreen;
        }

 
        public RestCollection<Carriers> Carriers { get; set; }

        public static bool IsInDesignMode
        {
            get
            {
                var prop = DesignerProperties.IsInDesignModeProperty;
                return (bool)DependencyPropertyDescriptor.FromProperty(prop, typeof(FrameworkElement)).Metadata.DefaultValue;
            }
        }
        

        private async void Carriers_Click(object sender, RoutedEventArgs e)
        {
            //redirect to Carrier's page
            
            CarriersWindow carrierwindow=new CarriersWindow();
            this.Visibility = Visibility.Hidden;
            carrierwindow.Show();
            


        }

        private void Customers_Click(object sender, RoutedEventArgs e)
        {
            //redirect to Customer's page
            CustomersWindow customerswindow=new CustomersWindow();
            this.Visibility = Visibility.Hidden;
            customerswindow.Show();
        }

        private void Invoices_Click(object sender, RoutedEventArgs e)
        {
            //redirect to invoice's page
            InvoicesWindow invoicesWindow=new InvoicesWindow();
            this.Visibility = Visibility.Hidden;
            invoicesWindow.Show();
        }

        private void Operators_Click(object sender, RoutedEventArgs e)
        {
            //redirect to Operator's page
            OperatorsWindow operatorswindow=new OperatorsWindow();
            this.Visibility = Visibility.Hidden;
            operatorswindow.Show();
        }

        private void Orders_Click(object sender, RoutedEventArgs e)
        {
            //redirect to Order's page
            OrdersWindow ordersWindow=new OrdersWindow();
            this.Visibility = Visibility.Hidden;    
            ordersWindow.Show();
        }

        private void Routes_Click(object sender, RoutedEventArgs e)
        {
            //redirect to Route's page
            RoutesWindow routeswindow=new RoutesWindow();
            this.Visibility = Visibility.Hidden;
            routeswindow.Show();
        }

        private void Temperatures_Click(object sender, RoutedEventArgs e)
        {
            //redirect to Temperatures's page
            TemperaturesWindow temperatureswindow=new TemperaturesWindow();
            this.Visibility = Visibility.Hidden;
            temperatureswindow.Show();
        }

        private void Tours_Click(object sender, RoutedEventArgs e)
        {
            //redirect to Tour's page
            ToursWindow toursWindow=new ToursWindow();
            this.Visibility = Visibility.Hidden;
            toursWindow.Show();
        }

        private void Trucks_Click(object sender, RoutedEventArgs e)
        {
            //redirect to Truck's page
            TrucksWindow trucksWindow=new TrucksWindow();
            this.Visibility = Visibility.Hidden;
            trucksWindow.Show();
        }

        private void Trailers_Click(object sender, RoutedEventArgs e)
        {
            //redirect to Trailers's page
            TrailersWindow trucksWindow=new TrailersWindow();
            this.Visibility = Visibility.Hidden;
            trucksWindow.Show();
        }

        private void Exit_bn(object sender, RoutedEventArgs e)
        {
            App.Current.Shutdown();
        }
    }
}
