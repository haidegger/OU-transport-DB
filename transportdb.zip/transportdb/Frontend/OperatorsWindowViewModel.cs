﻿using Microsoft.Toolkit.Mvvm.Input;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using System.Windows;
using transportdb.Frontend;
using transportdb.Models;
using Microsoft.Toolkit.Mvvm.ComponentModel;

namespace Frontend
{
    public class OperatorsWindowViewModel:ObservableRecipient
    {
        public RestCollection<Operators> Operators { get; set; }
        private Operators selectedOperator;
        public Operators SelectedOperator
        {
            get { return selectedOperator; }
            set
            {
                if (value != null)
                {
                    selectedOperator = new Operators()
                    {
                        Id = value.Id,
                        first_name=value.first_name,
                        last_name=value.last_name,
                        start_date=value.start_date,
                        to_id=value.to_id
                    };
                }
                OnPropertyChanged();
                (DeleteCommand as RelayCommand).NotifyCanExecuteChanged();
                (UpdateCommand as RelayCommand).NotifyCanExecuteChanged();
                (CreateCommand as RelayCommand).NotifyCanExecuteChanged();
            }
        }

        public ICommand CreateCommand { get; set; }
        public ICommand DeleteCommand { get; set; }
        public ICommand UpdateCommand { get; set; }

        public static bool IsInDesignMode
        {
            get
            {
                var prop = DesignerProperties.IsInDesignModeProperty;
                return (bool)DependencyPropertyDescriptor.FromProperty(prop, typeof(FrameworkElement)).Metadata.DefaultValue;
            }
        }
        public OperatorsWindowViewModel()
        {

            if (!IsInDesignMode)
            {
                Operators = new RestCollection<Operators>("https://localhost:7188/", "operators");

            }

            CreateCommand = new RelayCommand(() =>
            {
                Operators.Add(new Operators
                {
                    first_name = SelectedOperator.first_name,
                    last_name = SelectedOperator.last_name,
                    start_date = SelectedOperator.start_date,
                    to_id = SelectedOperator.to_id
                });
            },
            () =>
            {
                return SelectedOperator != null;
            });

            DeleteCommand = new RelayCommand(() =>
            {
                Operators.Delete(SelectedOperator.Id);
            },
            () =>
            {
                return SelectedOperator != null;
            });

            UpdateCommand = new RelayCommand(() =>
            {
                Operators.Update(SelectedOperator, SelectedOperator.Id);
            },
            () =>
            {
                return SelectedOperator != null;
            });

        }
    }
}
