﻿using Microsoft.Toolkit.Mvvm.Input;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using System.Windows;
using transportdb.Frontend;
using transportdb.Models;
using Microsoft.Toolkit.Mvvm.ComponentModel;

namespace Frontend
{
    public class CustomersWindowViewModel: ObservableRecipient
    {
        public RestCollection<Customers> Customers { get; set; }
        private Customers selectedCustomer;
        public Customers SelectedCustomer
        {
            get { return selectedCustomer; }
            set
            {
                if (value != null)
                {
                    selectedCustomer = new Customers()
                    {
                        Id = value.Id,
                        customer_id = value.customer_id,
                        city = value.city,
                        contact = value.contact,
                        customer_name = value.customer_name


                    };
                }
                OnPropertyChanged();
                (DeleteCommand as RelayCommand).NotifyCanExecuteChanged();
                (UpdateCommand as RelayCommand).NotifyCanExecuteChanged();
                (CreateCommand as RelayCommand).NotifyCanExecuteChanged();
            }
        }

        public ICommand CreateCommand { get; set; }
        public ICommand DeleteCommand { get; set; }
        public ICommand UpdateCommand { get; set; }

        public static bool IsInDesignMode
        {
            get
            {
                var prop = DesignerProperties.IsInDesignModeProperty;
                return (bool)DependencyPropertyDescriptor.FromProperty(prop, typeof(FrameworkElement)).Metadata.DefaultValue;
            }
        }


        public CustomersWindowViewModel()
        {

            if (!IsInDesignMode)
            {
                Customers = new RestCollection<Customers>("https://localhost:7188/", "customers");

            }

            CreateCommand = new RelayCommand(() =>
            {
                Customers.Add(new Customers
                {
                    customer_id = SelectedCustomer.customer_id,
                    city = SelectedCustomer.city,
                    contact = SelectedCustomer.contact,
                    customer_name = SelectedCustomer.customer_name
                });
            },
            () =>
            {
                return SelectedCustomer != null;
            });

            DeleteCommand = new RelayCommand(() =>
            {
                Customers.Delete(SelectedCustomer.Id);
            },
            () =>
            {
                return SelectedCustomer != null;
            });

            UpdateCommand = new RelayCommand(() =>
            {
                Customers.Update(SelectedCustomer, SelectedCustomer.Id);
            },
            () =>
            {
                return SelectedCustomer != null;
            });

        }
    }
}
