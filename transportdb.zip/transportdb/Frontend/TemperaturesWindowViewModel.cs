﻿using Microsoft.Toolkit.Mvvm.Input;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using System.Windows;
using transportdb.Frontend;
using transportdb.Models;
using Microsoft.Toolkit.Mvvm.ComponentModel;

namespace Frontend
{
    public class TemperaturesWindowViewModel:ObservableRecipient
    {
        public RestCollection<Temperatures> Temperatures { get; set; }
        private Temperatures selectedTemp;
        public Temperatures SelectedTemp
        {
            get { return selectedTemp; }
            set
            {
                if (value != null)
                {
                    selectedTemp = new Temperatures()
                    {
                        Id = value.Id,
                        temperature_name=value.temperature_name,
                        signal=value.signal,
                        celsius=value.celsius
                    };
                }
                OnPropertyChanged();
                (DeleteCommand as RelayCommand).NotifyCanExecuteChanged();
                (UpdateCommand as RelayCommand).NotifyCanExecuteChanged();
                (CreateCommand as RelayCommand).NotifyCanExecuteChanged();
            }
        }

        public ICommand CreateCommand { get; set; }
        public ICommand DeleteCommand { get; set; }
        public ICommand UpdateCommand { get; set; }

        public static bool IsInDesignMode
        {
            get
            {
                var prop = DesignerProperties.IsInDesignModeProperty;
                return (bool)DependencyPropertyDescriptor.FromProperty(prop, typeof(FrameworkElement)).Metadata.DefaultValue;
            }
        }
        public TemperaturesWindowViewModel()
        {

            if (!IsInDesignMode)
            {
                Temperatures = new RestCollection<Temperatures>("https://localhost:7188/", "temperatures");

            }

            CreateCommand = new RelayCommand(() =>
            {
                Temperatures.Add(new Temperatures
                {
                    temperature_name = SelectedTemp.temperature_name,
                    signal = SelectedTemp.signal,
                    celsius = SelectedTemp.celsius
                });
            },
            () =>
            {
                return SelectedTemp != null;
            });

            DeleteCommand = new RelayCommand(() =>
            {
                Temperatures.Delete(SelectedTemp.Id);
            },
            () =>
            {
                return SelectedTemp != null;
            });

            UpdateCommand = new RelayCommand(() =>
            {
                Temperatures.Update(SelectedTemp, SelectedTemp.Id);
            },
            () =>
            {
                return SelectedTemp != null;
            });

        }
    }
}
