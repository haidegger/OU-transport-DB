﻿using Microsoft.Toolkit.Mvvm.Input;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using System.Windows;
using transportdb.Frontend;
using transportdb.Models;
using Microsoft.Toolkit.Mvvm.ComponentModel;

namespace Frontend
{
    public class ToursWindowViewModel:ObservableRecipient
    {
        public RestCollection<Tours> Tours { get; set; }
        private Tours selectedTour;
        public Tours SelectedTour

        {
            get { return selectedTour; }
            set
            {
                if (value != null)
                {
                    selectedTour = new Tours()
                    {
                        Id = value.Id,
                        tour_nr = value.tour_nr,
                        carrier_id = value.carrier_id,
                        TO_id=value.TO_id,
                        invoice_nr = value.invoice_nr,
                        tour_end=value.tour_end,
                        order_nr = value.order_nr,
                        route_id = value.route_id
                        
                    };
                }
                OnPropertyChanged();
                (DeleteCommand as RelayCommand).NotifyCanExecuteChanged();
                (UpdateCommand as RelayCommand).NotifyCanExecuteChanged();
                (CreateCommand as RelayCommand).NotifyCanExecuteChanged();
            }
        }

        public ICommand CreateCommand { get; set; }
        public ICommand DeleteCommand { get; set; }
        public ICommand UpdateCommand { get; set; }

        public static bool IsInDesignMode
        {
            get
            {
                var prop = DesignerProperties.IsInDesignModeProperty;
                return (bool)DependencyPropertyDescriptor.FromProperty(prop, typeof(FrameworkElement)).Metadata.DefaultValue;
            }
        }
        public ToursWindowViewModel()
        {

            if (!IsInDesignMode)
            {
                Tours = new RestCollection<Tours>("https://localhost:7188/", "tours");

            }

            CreateCommand = new RelayCommand(() =>
            {
                Tours.Add(new Tours
                {
                    tour_nr = SelectedTour.tour_nr,
                    carrier_id = SelectedTour.carrier_id,
                    TO_id = SelectedTour.TO_id,
                    invoice_nr = SelectedTour.invoice_nr,
                    tour_end = SelectedTour.tour_end,
                    order_nr = SelectedTour.order_nr,
                    route_id = SelectedTour.route_id
                });
            },
            () =>
            {
                return SelectedTour != null;
            });

            DeleteCommand = new RelayCommand(() =>
            {
                Tours.Delete(SelectedTour.Id);
            },
            () =>
            {
                return SelectedTour != null;
            });

            UpdateCommand = new RelayCommand(() =>
            {
                Tours.Update(SelectedTour, SelectedTour.Id);
            },
            () =>
            {
                return SelectedTour != null;
            });

        }
    }
}
