﻿using Microsoft.Toolkit.Mvvm.Input;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using System.Windows;
using transportdb.Frontend;
using transportdb.Models;
using Microsoft.Toolkit.Mvvm.ComponentModel;

namespace Frontend
{
    public class RoutesWindowViewModel:ObservableRecipient
    {
        public RestCollection<Routes> Routes { get; set; }
        private Routes selectedRoute;
        public Routes SelectedRoute
        {
            get { return selectedRoute; }
            set
            {
                if (value != null)
                {
                    selectedRoute = new Routes()
                    {
                        Id = value.Id,
                        route_id=value.route_id,
                        destination = value.destination,
                        start_loc = value.start_loc
                    };
                }
                OnPropertyChanged();
                (DeleteCommand as RelayCommand).NotifyCanExecuteChanged();
                (UpdateCommand as RelayCommand).NotifyCanExecuteChanged();
                (CreateCommand as RelayCommand).NotifyCanExecuteChanged();
            }
        }

        public ICommand CreateCommand { get; set; }
        public ICommand DeleteCommand { get; set; }
        public ICommand UpdateCommand { get; set; }

        public static bool IsInDesignMode
        {
            get
            {
                var prop = DesignerProperties.IsInDesignModeProperty;
                return (bool)DependencyPropertyDescriptor.FromProperty(prop, typeof(FrameworkElement)).Metadata.DefaultValue;
            }
        }
        public RoutesWindowViewModel()
        {

            if (!IsInDesignMode)
            {
                Routes = new RestCollection<Routes>("https://localhost:7188/", "routes");

            }

            CreateCommand = new RelayCommand(() =>
            {
                Routes.Add(new Routes
                {
                    route_id = SelectedRoute.route_id,
                    destination = SelectedRoute.destination,
                    start_loc = SelectedRoute.start_loc
                });
            },
            () =>
            {
                return SelectedRoute != null;
            });

            DeleteCommand = new RelayCommand(() =>
            {
                Routes.Delete(SelectedRoute.Id);
            },
            () =>
            {
                return SelectedRoute != null;
            });

            UpdateCommand = new RelayCommand(() =>
            {
                Routes.Update(SelectedRoute, SelectedRoute.Id);
            },
            () =>
            {
                return SelectedRoute != null;
            });

        }
    }
}
