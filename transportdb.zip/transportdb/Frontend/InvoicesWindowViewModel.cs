﻿using Microsoft.Toolkit.Mvvm.Input;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using System.Windows;
using transportdb.Frontend;
using transportdb.Models;
using Microsoft.Toolkit.Mvvm.ComponentModel;

namespace Frontend
{
    public class InvoicesWindowViewModel:ObservableRecipient
    {
        public RestCollection<Invoices> Invoices { get; set; }
        private Invoices selectedInvoice;
        public Invoices SelectedInvoice
        {
            get { return selectedInvoice; }
            set
            {
                if (value != null)
                {
                    selectedInvoice = new Invoices()
                    {
                        Id = value.Id,
                        invoice_nr = value.invoice_nr,
                        currency = value.currency,
                        price = value.price
                    };
                }
                OnPropertyChanged();
                (DeleteCommand as RelayCommand).NotifyCanExecuteChanged();
                (UpdateCommand as RelayCommand).NotifyCanExecuteChanged();
                (CreateCommand as RelayCommand).NotifyCanExecuteChanged();
            }
        }

        public ICommand CreateCommand { get; set; }
        public ICommand DeleteCommand { get; set; }
        public ICommand UpdateCommand { get; set; }

        public static bool IsInDesignMode
        {
            get
            {
                var prop = DesignerProperties.IsInDesignModeProperty;
                return (bool)DependencyPropertyDescriptor.FromProperty(prop, typeof(FrameworkElement)).Metadata.DefaultValue;
            }
        }
        public InvoicesWindowViewModel()
        {

            if (!IsInDesignMode)
            {
                Invoices = new RestCollection<Invoices>("https://localhost:7188/", "invoices");

            }

            CreateCommand = new RelayCommand(() =>
            {
                Invoices.Add(new Invoices
                {
                    invoice_nr=SelectedInvoice.invoice_nr,
                    currency=SelectedInvoice.currency,
                    price=SelectedInvoice.price
                });
            },
            () =>
            {
                return SelectedInvoice != null;
            });

            DeleteCommand = new RelayCommand(() =>
            {
                Invoices.Delete(SelectedInvoice.Id);
            },
            () =>
            {
                return SelectedInvoice != null;
            });

            UpdateCommand = new RelayCommand(() =>
            {
                Invoices.Update(SelectedInvoice, SelectedInvoice.Id);
            },
            () =>
            {
                return SelectedInvoice != null;
            });

        }
    }
}
