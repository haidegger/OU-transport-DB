﻿using Microsoft.Toolkit.Mvvm.Input;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using System.Windows;
using transportdb.Frontend;
using transportdb.Models;
using Microsoft.Toolkit.Mvvm.ComponentModel;

namespace Frontend
{
    public class OrdersWindowViewModel:ObservableRecipient
    {
        public RestCollection<Orders> Orders { get; set; }
        private Orders selectedOrder;
        public Orders SelectedOrder
        {
            get { return selectedOrder; }
            set
            {
                if (value != null)
                {
                    selectedOrder = new Orders()
                    {
                        Id = value.Id,
                        order_nr = value.order_nr,
                        customer_id = value.customer_id,
                        palet_number = value.palet_number,
                        temperature_name = value.temperature_name
                    };
                }
                OnPropertyChanged();
                (DeleteCommand as RelayCommand).NotifyCanExecuteChanged();
                (UpdateCommand as RelayCommand).NotifyCanExecuteChanged();
                (CreateCommand as RelayCommand).NotifyCanExecuteChanged();
            }
        }

        public ICommand CreateCommand { get; set; }
        public ICommand DeleteCommand { get; set; }
        public ICommand UpdateCommand { get; set; }

        public static bool IsInDesignMode
        {
            get
            {
                var prop = DesignerProperties.IsInDesignModeProperty;
                return (bool)DependencyPropertyDescriptor.FromProperty(prop, typeof(FrameworkElement)).Metadata.DefaultValue;
            }
        }
        public OrdersWindowViewModel()
        {

            if (!IsInDesignMode)
            {
                Orders = new RestCollection<Orders>("https://localhost:7188/", "orders");

            }

            CreateCommand = new RelayCommand(() =>
            {
                Orders.Add(new Orders
                {
                    order_nr = SelectedOrder.order_nr,
                    customer_id = SelectedOrder.customer_id,
                    palet_number = SelectedOrder.palet_number,
                    temperature_name = SelectedOrder.temperature_name
                });
            },
            () =>
            {
                return SelectedOrder != null;
            });

            DeleteCommand = new RelayCommand(() =>
            {
                Orders.Delete(SelectedOrder.Id);
            },
            () =>
            {
                return SelectedOrder != null;
            });

            UpdateCommand = new RelayCommand(() =>
            {
                Orders.Update(SelectedOrder, SelectedOrder.Id);
            },
            () =>
            {
                return SelectedOrder != null;
            });

        }
    }
}
