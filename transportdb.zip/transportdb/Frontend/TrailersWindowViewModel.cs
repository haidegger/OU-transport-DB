﻿using Microsoft.Toolkit.Mvvm.ComponentModel;
using Microsoft.Toolkit.Mvvm.Input;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using System.Windows;
using transportdb.Frontend;
using transportdb.Models;

namespace Frontend
{
    public class TrailersWindowViewModel:ObservableRecipient
    {
        public RestCollection<Trailers> Trailers { get; set; }
        private Trailers selectedTrailer;
        public Trailers SelectedTrailer
        {
            get { return selectedTrailer; }
            set
            {
                if (value != null)
                {
                    selectedTrailer = new Trailers()
                    {
                        Id = value.Id,
                        trailer_nrplate=value.trailer_nrplate,
                        country=value.country,
                        type=value.type
                    };
                }
                OnPropertyChanged();
                (DeleteCommand as RelayCommand).NotifyCanExecuteChanged();
                (UpdateCommand as RelayCommand).NotifyCanExecuteChanged();
                (CreateCommand as RelayCommand).NotifyCanExecuteChanged();
            }
        }

        public ICommand CreateCommand { get; set; }
        public ICommand DeleteCommand { get; set; }
        public ICommand UpdateCommand { get; set; }

        public static bool IsInDesignMode
        {
            get
            {
                var prop = DesignerProperties.IsInDesignModeProperty;
                return (bool)DependencyPropertyDescriptor.FromProperty(prop, typeof(FrameworkElement)).Metadata.DefaultValue;
            }
        }
        public TrailersWindowViewModel()
        {

            if (!IsInDesignMode)
            {
                Trailers = new RestCollection<Trailers>("https://localhost:7188/", "trailers");

            }

            CreateCommand = new RelayCommand(() =>
            {
                Trailers.Add(new Trailers
                {
                    trailer_nrplate = SelectedTrailer.trailer_nrplate,
                    country = SelectedTrailer.country,
                    type = SelectedTrailer.type
                });
            },
            () =>
            {
                return SelectedTrailer != null;
            });

            DeleteCommand = new RelayCommand(() =>
            {
                Trailers.Delete(SelectedTrailer.Id);
            },
            () =>
            {
                return SelectedTrailer != null;
            });

            UpdateCommand = new RelayCommand(() =>
            {
                Trailers.Update(SelectedTrailer, SelectedTrailer.Id);
            },
            () =>
            {
                return SelectedTrailer != null;
            });

        }
    }
}
